#include "Stats.h"

Stat pocet_dni("Pocet dni");
Stat pocet_pracovnych_dni("Pocet pracovnych dni");
Stat pocet_dazd("Pocet dni s dazdom");


Stat hodiny_harvester("pocet hodin harvester cakal na traktor");
Stat hodiny_traktor("Pocet hodin traktor cakal na kombajn");
