# Projekt IMS 2023 SHO V HOSPODARSTVE
## autory
Matus Gazdik xgazdi04
Peter Kovac xkovac66

projekt vypisuje warning s kazdym behom funguje vsak spravne
