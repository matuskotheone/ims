#ifndef STATS_H
#define STATS_H

#include <iostream>
#include "simlib.h"

extern Stat pocet_dni;
extern Stat pocet_dazd;
extern Stat pocet_pracovnych_dni;

extern Stat hodiny_harvester;
extern Stat hodiny_traktor;

#endif // STATS_H
